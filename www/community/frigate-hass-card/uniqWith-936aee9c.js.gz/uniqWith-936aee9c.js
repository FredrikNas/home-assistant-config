import{c1 as o}from"./card-67eaecc9.js";function t(t,c){return c="function"==typeof c?c:void 0,t&&t.length?o(t,void 0,c):[]}export{t as u};
